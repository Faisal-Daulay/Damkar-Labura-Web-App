<?php
// Load file koneksi.php
include "../config.php";
$start=date('Y-m-d',strtotime($_POST['start_date']));
$end=date('Y-m-d',strtotime($_POST['end_date']));
// Load plugin PHPExcel nya
require_once 'PHPExcel/PHPExcel.php';

// Panggil class PHPExcel nya
$csv = new PHPExcel();

// Settingan awal fil excel
$csv->getProperties()->setCreator('My Notes Code')
                       ->setLastModifiedBy('My Notes Code')
                       ->setTitle("Data Pengguna")
                       ->setSubject("Pengguna")
                       ->setDescription("Laporan Semua Data Pengguna")
                       ->setKeywords("Data Pengguna");

// Buat header tabel nya pada baris ke 1
$csv->setActiveSheetIndex(0)->setCellValue('A1', "NO"); // Set kolom A1 dengan tulisan "NO"
$csv->setActiveSheetIndex(0)->setCellValue('B1', "NAMA"); // Set kolom B1 dengan tulisan "NIS"
$csv->setActiveSheetIndex(0)->setCellValue('C1', "ALAMAT"); // Set kolom C1 dengan tulisan "NAMA"
$csv->setActiveSheetIndex(0)->setCellValue('D1', "NOMOR HP"); // Set kolom D1 dengan tulisan "JENIS KELAMIN"
$csv->setActiveSheetIndex(0)->setCellValue('E1', "TANGGAL DAFTAR"); // Set kolom E1 dengan tulisan "TELEPON"
// $csv->setActiveSheetIndex(0)->setCellValue('F1', "ALAMAT"); // Set kolom F1 dengan tulisan "ALAMAT"

// Buat query untuk menampilkan semua data siswa
$sql = mysqli_query($db, "SELECT * FROM pengguna WHERE tgl_daftar >='$start' AND tgl_daftar <='$end' ");

$no = 1; // Untuk penomoran tabel, di awal set dengan 1
$numrow = 2; // Set baris pertama untuk isi tabel adalah baris ke 2
while($data = mysqli_fetch_array($sql)){ // Ambil semua data dari hasil eksekusi $sql
    $csv->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $no);
    $csv->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $data['nama']);
    $csv->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $data['alamat']);
    
    // Khusus untuk no telepon. kita set type kolom nya jadi STRING
    $csv->setActiveSheetIndex(0)->setCellValueExplicit('D'.$numrow, $data['no_hp'], PHPExcel_Cell_DataType::TYPE_STRING);
    $csv->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $data['tgl_daftar']);
    
    $no++; // Tambah 1 setiap kali looping
    $numrow++; // Tambah 1 setiap kali looping
}

// Set orientasi kertas jadi LANDSCAPE
$csv->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);

// Set judul file excel nya
$csv->getActiveSheet(0)->setTitle("Report Data Pengguna");
$csv->setActiveSheetIndex(0);

// Proses file excel
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="Data Pengguna.xls"'); // Set nama file excel nya
header('Cache-Control: max-age=0');

$write = new PHPExcel_Writer_Excel2007($csv);
$write->save('php://output');
?>
